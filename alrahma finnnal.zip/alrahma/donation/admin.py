from django.contrib import admin
from django.contrib.auth.models import User
from .models import Profile, Sections, Donations, Pickups, Events, EventsRegistration, Appointments

# Register your models here.
admin.site.register(Profile)
admin.site.register(Sections)
admin.site.register(Donations)
admin.site.register(Pickups)
admin.site.register(Events)
admin.site.register(EventsRegistration)
class AppointmentsAdmin(admin.ModelAdmin):
    model = User
    list_display = ['username', 'get_name', ]

    def get_name(self, obj):
        return obj.user_id.name
    get_name.admin_order_field  = 'username'  #Allows column order sorting
    get_name.short_description = 'User Name'  #Renames column head


admin.site.register(Appointments)
