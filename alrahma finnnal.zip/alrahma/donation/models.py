from django.db import models
from django.contrib.auth.models import User

class Sections(models.Model):
    title = models.CharField(max_length=500)
    creation_date =  models.DateField(auto_now_add=True)

    def __str__(self):
        return self.title
    
    class Meta:
        managed = True
        db_table = 'Sections'

class Donations(models.Model):
    title = models.CharField(max_length=500)
    description = models.TextField(null=True, blank=True)
    photo = models.ImageField(upload_to='images/', default='images/placeholder.jpg')
    section_id = models.ForeignKey(Sections, on_delete=models.CASCADE)
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    creation_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.title
    
    class Meta:
        managed = True
        db_table = 'Donations'

class Pickups(models.Model):
    item_id = models.ForeignKey(Donations, on_delete=models.CASCADE)
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    creation_date =  models.DateField(auto_now_add=True)

    def __str__(self):
        return self.item_id.title
    
    class Meta:
        managed = True
        db_table = 'Pickups'

class Events(models.Model):
    title = models.CharField(max_length=500)
    description = models.TextField(null=True, blank=True)
    image = models.ImageField(upload_to='images/', default='images/placeholder.jpg')
    event_date = models.DateField(null=True, blank=True)
    creation_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.title
    
    class Meta:
        managed = True
        db_table = 'Events'

class EventsRegistration(models.Model):
    event_id = models.ForeignKey(Events, on_delete=models.CASCADE)
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    creation_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.event_id.title
    
    class Meta:
        managed = True
        db_table = 'Events Registration'

class Appointments(models.Model):
    department = models.CharField(max_length=500)
    msg = models.TextField(null=True, blank=True)
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    book_date = models.DateField(null=True, blank=True)
    creation_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.department
    
    class Meta:
        managed = True
        db_table = 'Appointments'

class Profile(models.Model):
    account_type = (
        ('donor', 'Donor'),
        ('benefiter', 'Benefiter'),
    )
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='user_profile')
    mobile = models.CharField(max_length=10, null=True, blank=True)
    userType = models.CharField(max_length=255, choices=account_type, null=True, blank=True)
    address = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.user.username
