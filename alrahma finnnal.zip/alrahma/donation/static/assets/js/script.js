
      $(document).ready(function(){
        $('.menu-hamburger').click(function(){
          $('.menu-hamburger').toggleClass('active')
          $('.menu').toggleClass('active')
        });
      });

function validation(e) {

  if(e.name.value == '' || e.email.value == '' || e.address.value == ''){
    $('#error_msg').removeClass('d-none').html("Please fill in all the required inputs.")
    return false;
  } else if(e.mobile.value.length < 7) {
    $('#error_msg').removeClass('d-none').html("Please enter a valid mobile number.")
    return false;
  } else if(e.password.value !== e.rpassword.value){
    $('#error_msg').removeClass('d-none').html("Passwords are not matched try again.")
    return false;
  } else if (!e.email.value.inclues('@')){
    $('#error_msg').removeClass('d-none').html("Enter a valid email.")
    return false;
  }

  $('#error_msg').addClass('d-none')
  return true;
}