from django import forms
from .models import Donations
 
class DonationForm(forms.ModelForm):
 
    class Meta:
        model = Donations
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Title'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Description'}),
            'photo': forms.FileInput(attrs={'class': 'form-control mb-5', 'placeholder': 'photo'}),
            'section_id': forms.Select(attrs={'class': 'form-control', 'label': 'Section'}),
        }
        fields = ['section_id', 'title', 'description', 'photo', ]