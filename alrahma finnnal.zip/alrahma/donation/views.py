from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth import logout, login, authenticate
from django.core.mail import EmailMessage

from .models import Sections, Profile, User, Donations, Pickups, Events, EventsRegistration, Appointments
from .forms import DonationForm

def home_view(request):
    sections = Sections.objects.all().order_by('-id')
    donations = Donations.objects.all().order_by('-id')[0:6]

    return render(request, 'home.html', { "sections": sections, "donations": donations})

def feedback_view(request):
    if request.method == 'POST':
        name = request.POST["name"]
        email = request.POST["email"]
        subject = request.POST["subject"]
        msg = request.POST["text"]
        message = name + "\n" + email + '\n' + msg
        if name and subject and msg and email:
            try:
                msg = EmailMessage(subject, message, "muhanedmossa@gmail.com", ["muhanedmossa@gmail.com"])
                msg.send()
            except Exception as err:
                return render(request, 'feedback.html', {'error': True})
            
            return redirect("thanks/")
        else:
            return render(request, 'feedback.html', {'error': True})
    else:
        return render(request, 'feedback.html')

def details_view(request, item):
    if request.method == 'POST':
        item = request.POST['item']
        donations_item = Donations.objects.filter(id=item).get()
        donate_track = Pickups(user_id = request.user, item_id = donations_item)
        donate_track.save()
        
    details = Donations.objects.filter(id=item).get()
    try:
        item_backtracks = Pickups.objects.filter(item_id=details).get()
    except:
        item_backtracks = None

    return render(request, 'details.html', {"details": details, "backtracks": item_backtracks})

def donations_view(request, category):
    if category:
        section = Sections.objects.filter(id=category).get()
        donations = Donations.objects.filter(section_id=section).order_by('-id')
    else:
        donations = Donations.objects.all().order_by('-id')
    
    sections = Sections.objects.all().order_by('-id')
    return render(request, 'donations.html', { "donations": donations, "sections": sections })


def signup_view(request):
    if request.method == 'POST':
            username_exist = False
            email_exist = False
            # check if user does not exist
            if User.objects.filter(username=request.POST["username"]).exists():
                username_exist = True

            if User.objects.filter(email=request.POST["email"]).exists():
                email_exist = True

            if not email_exist and not username_exist:
                user = User.objects.create_user(username=request.POST["username"], password=request.POST["password"])
                user.first_name = request.POST["firstname"]
                user.last_name = request.POST["lastname"]
                user.email = request.POST["email"]
                user.is_active = True

                user.save()

                profile = Profile()
                profile.user = user
                profile.userType = request.POST["user_type"]
                profile.mobile = request.POST["mobile"]
                profile.address = request.POST["address"]

                profile.save()

                return redirect("/")
            else:
                return render(request, 'signup.html', {'signup_error': True})

    return render(request, 'signup.html')

def signin_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(username=username, password=password)
        if user is not None:
            login(request=request, user=user)

            return redirect("profile")
        else:
            return render(request, 'signin.html', {'error': True})
        
    return render(request, 'signin.html')

def signout_view(request):
    logout(request)
    return redirect('/')

def profile_view(request):
    if request.user.is_authenticated == False:
       return redirect("signin")
    
    profile = Profile.objects.filter(user=request.user).get()

    if profile.userType == 'donor':
        donations = Donations.objects.filter(user_id=request.user).order_by('-id')
    else:
        donations = Pickups.objects.filter(user_id=request.user).order_by('-id')

    if request.method == 'POST':
        item = request.POST['item']
        Donations.objects.filter(id=item).delete()

    return render(request, 'profile.html', { "profile": profile, "donations": donations })

def edit_profile_view(request):
    profile = Profile.objects.get(user=request.user)
    if request.method == 'POST':
        user = User.objects.get(id=request.user.id)
        user.first_name = request.POST["firstname"]
        user.last_name = request.POST["lastname"]
        user.email = request.POST["email"]

        user.save()

        profile.mobile = request.POST["mobile"]
        profile.address = request.POST["address"]

        profile.save()

        return redirect("/profile")

    return render(request, 'edit-profile.html', { "profile": profile })

def donate_view(request):
    if request.user.is_authenticated == False:
       return redirect("signin")
    
    donate_form = DonationForm()
    if request.method == 'POST':
        donate_form = DonationForm(request.POST, request.FILES)

        if donate_form.is_valid():
            donate = donate_form.save(commit=False)
            donate.user_id = request.user
            donate.save()
            return redirect('profile')

    return render(request, 'donate.html', {'form': donate_form})

def edit_donation_view(request, item):
    donation = Donations.objects.filter(id=item).get()

    donate_form = DonationForm(request.POST or None, instance=donation)
    if donate_form.is_valid():
        donate_form.save()

        return redirect('profile')

    return render(request, 'edit-donation.html', { "form": donate_form })

def events_view(request):
    events_list = Events.objects.all().order_by('-id')

    return render(request, 'events.html', { "events_list": events_list })

def event_view(request, item):
    if request.method == 'POST':
        if request.user.is_authenticated == False:
            return redirect("signin")
    
        item = request.POST['item']
        donations_item = Events.objects.filter(id=item).get()
        donate_track = EventsRegistration(user_id = request.user, event_id = donations_item)
        donate_track.save()
        
    event_details = Events.objects.filter(id=item).get()

    try:
        event_backtracks = EventsRegistration.objects.filter(event_id=event_details).get()
    except:
        event_backtracks = None

    return render(request, 'event.html', {"details": event_details, "backtracks": event_backtracks})


def contact_view(request):
    if request.method == 'POST':
        if request.user.is_authenticated == False:
            return redirect("signin")
        
        max_appointemnts_per_day = 5

        #department = request.POST.get('department', False)
        department = request.POST["department"]
        #msg = request.POST["msg"]
        msg = request.POST.get("msg")
        book_date = request.POST.get('bookDate', False)

        appointments = Appointments.objects.filter(book_date = book_date, department = department)
        print(appointments)
        if(max_appointemnts_per_day > len(appointments)):

            book = Appointments(department = department, user_id = request.user, msg = msg, book_date=book_date)
            book.save()
            return redirect('thanks')
        else:
            return render(request, 'contact.html', {'error': True})


    return render(request, 'contact.html', {'error': False})

def thanks_view(request):

    return render(request, 'thanks.html')