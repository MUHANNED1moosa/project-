from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('', views.home_view, name='home'),
    path('signup/', views.signup_view, name='signup'),
    path('signin/', views.signin_view, name='signin'),
    path('signout/', views.signout_view, name='signout'),
    path('profile/', views.profile_view, name='profile'),
    path('details/<int:item>', views.details_view, name='details'),
    path('donations/<int:category>', views.donations_view, name='donations'),
    path('donations/', views.donations_view, kwargs={'category': None}, name='donations'),
    path('donate/', views.donate_view, name='donate'),
    path('edit-donation/<int:item>', views.edit_donation_view, name='edit-donation'),
    path('events/', views.events_view, name='events'),
    path('events/<int:item>', views.event_view, name='event'),
    path('feedback/', views.feedback_view, name='feedback'),
    path('contact/', views.contact_view, name='contact'),
    path('thanks/', views.thanks_view, name='thanks'),
    path('edit-profile/', views.edit_profile_view, name='edit-profile')

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
